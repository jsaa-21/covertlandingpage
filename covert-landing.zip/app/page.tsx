import Link from "next/link"
import Image from "next/image"
import { ChevronRight, Instagram, Linkedin, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col bg-[#0C0C0C] text-white">
      <header className="container z-40 flex h-20 items-center justify-between py-6">
        <div className="flex items-center gap-2 text-xl font-bold">
          <span className="text-[#00E5FF]">COVERT</span>
        </div>
        <nav className="hidden gap-6 md:flex">
          <Link href="#features" className="text-sm font-medium hover:text-[#00E5FF] transition-colors">
            Features
          </Link>
          <Link href="#how-it-works" className="text-sm font-medium hover:text-[#00E5FF] transition-colors">
            How It Works
          </Link>
          <Link href="#waitlist" className="text-sm font-medium hover:text-[#00E5FF] transition-colors">
            Join Waitlist
          </Link>
        </nav>
        <Button className="hidden md:flex bg-[#00E5FF] text-black hover:bg-[#00E5FF]/90">Join Waitlist</Button>
      </header>
      <main className="flex-1">
        <section className="relative py-20 md:py-28 lg:py-40 overflow-hidden">
          <div className="container relative z-10 flex flex-col items-center text-center">
            <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl max-w-3xl">
              Your Watch. <span className="text-[#00E5FF]">Upgraded.</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg text-zinc-400 md:text-xl">
              Turn any watch into a powerful fitness tracker with Covert — the sleek sensor that does it all without
              compromising your style.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-[#00E5FF] text-black hover:bg-[#00E5FF]/90">
                Join the Waitlist
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" className="border-zinc-800 hover:bg-zinc-800">
                Learn More
              </Button>
            </div>
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-full max-w-2xl mx-auto mt-20 md:mt-0">
              <Image
                src="/placeholder.svg?height=600&width=800"
                width={800}
                height={600}
                alt="Luxury watch with Covert sensor"
                className="mx-auto"
                priority
              />
              <div className="absolute inset-0 bg-gradient-radial from-[#00E5FF]/20 to-transparent opacity-70 blur-2xl"></div>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0C0C0C] pointer-events-none"></div>
        </section>

        <section className="py-20 md:py-28">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Look Classic. <span className="text-[#00E5FF]">Track Like an Athlete.</span>
              </h2>
              <p className="mt-4 text-zinc-400 max-w-2xl mx-auto">Track everything. Show nothing.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center p-6 rounded-lg bg-zinc-900/50 border border-zinc-800">
                <div className="h-12 w-12 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-4">
                  <span className="text-[#00E5FF] text-xl">1</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Invisible Design</h3>
                <p className="text-zinc-400">
                  Sits discreetly under your favorite watch — no double wristing, no rings.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-lg bg-zinc-900/50 border border-zinc-800">
                <div className="h-12 w-12 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-4">
                  <span className="text-[#00E5FF] text-xl">2</span>
                </div>
                <h3 className="text-xl font-bold mb-2">Advanced Tracking</h3>
                <p className="text-zinc-400">Heart rate, activity, sleep — all in real time.</p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-lg bg-zinc-900/50 border border-zinc-800">
                <div className="h-12 w-12 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-4">
                  <span className="text-[#00E5FF] text-xl">3</span>
                </div>
                <h3 className="text-xl font-bold mb-2">One Wrist Life</h3>
                <p className="text-zinc-400">Keep your style. Keep your health data.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-zinc-950">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ever see this before?</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
              <div className="relative rounded-lg overflow-hidden aspect-video">
                <Image
                  src="/images/apple-watch-rolex.avif"
                  width={600}
                  height={400}
                  alt="Person wearing Apple Watch and Rolex"
                  className="object-cover w-full h-full"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                  <p className="text-lg font-medium">Double wristing: Apple Watch + Luxury timepiece</p>
                </div>
              </div>
              <div className="relative rounded-lg overflow-hidden aspect-video">
                <Image
                  src="/placeholder.svg?height=400&width=600"
                  width={600}
                  height={400}
                  alt="Person wearing fitness tracker and luxury watch on same wrist"
                  className="object-cover w-full h-full"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-6">
                  <p className="text-lg font-medium">Bulky combination: Fitness band + Watch on same wrist</p>
                </div>
              </div>
            </div>
            <div className="text-center max-w-2xl mx-auto">
              <p className="text-[#00E5FF] font-medium mb-2">Fitness should be simple.</p>
              <h3 className="text-2xl font-bold mb-6 md:text-3xl">
                You shouldn't have to choose between data and design.
              </h3>
              <p className="text-zinc-400">
                Covert gives you the best of both worlds: the classic look of your favorite timepiece with the advanced
                tracking capabilities of modern fitness technology.
              </p>
            </div>
          </div>
        </section>

        <section id="features" className="py-20 md:py-28">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Packed with <span className="text-[#00E5FF]">Power.</span>
              </h2>
              <p className="mt-4 text-zinc-400 max-w-2xl mx-auto">Small in size. Big on features.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                {
                  title: "Heart Rate Sensor",
                  description: "Skin-facing optical heart rate sensor provides continuous monitoring",
                },
                {
                  title: "Step & Sleep Tracking",
                  description: "Advanced algorithms track your daily activity and sleep patterns",
                },
                {
                  title: "7-Day Battery Life",
                  description: "Long-lasting battery means less charging, more tracking",
                },
                {
                  title: "Health App Integration",
                  description: "Seamlessly syncs with Apple Health and Google Fit",
                },
                {
                  title: "Secure Attachment",
                  description: "Magnetic or adhesive attachment that won't damage your watch",
                },
                {
                  title: "Water & Sweat Resistant",
                  description: "Durable design stands up to your active lifestyle",
                },
              ].map((feature, index) => (
                <div key={index} className="flex flex-col p-6 rounded-lg bg-zinc-900/50 border border-zinc-800">
                  <div className="h-10 w-10 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-4">
                    <span className="text-[#00E5FF]">{index + 1}</span>
                  </div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-zinc-400">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="how-it-works" className="py-20 md:py-28 bg-zinc-950">
          <div className="container">
            <div className="flex flex-col lg:flex-row gap-12 items-center">
              <div className="flex-1">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">
                  How Covert <span className="text-[#00E5FF]">Works</span>
                </h2>
                <div className="space-y-8">
                  {[
                    {
                      step: "1",
                      title: "Attach to your watch",
                      description: "The quarter-sized sensor attaches securely to the back of any watch.",
                    },
                    {
                      step: "2",
                      title: "Connect the app",
                      description: "Pair with our mobile app to customize your tracking preferences.",
                    },
                    {
                      step: "3",
                      title: "Wear as normal",
                      description: "Continue wearing your favorite timepiece while Covert tracks your health metrics.",
                    },
                  ].map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="h-10 w-10 rounded-full bg-[#00E5FF]/20 flex-shrink-0 flex items-center justify-center">
                        <span className="text-[#00E5FF]">{item.step}</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-bold mb-1">{item.title}</h3>
                        <p className="text-zinc-400">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex-1 relative">
                <Image
                  src="/placeholder.svg?height=600&width=600"
                  width={600}
                  height={600}
                  alt="How Covert works"
                  className="rounded-lg"
                />
                <div className="absolute inset-0 bg-gradient-radial from-[#00E5FF]/20 to-transparent opacity-50 blur-2xl"></div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28">
          <div className="container">
            <div className="flex flex-col lg:flex-row gap-12 items-center">
              <div className="flex-1 order-2 lg:order-1">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl mb-6">
                  Sticks Like <span className="text-[#00E5FF]">Science Fiction.</span>
                </h2>
                <p className="text-xl text-zinc-300 mb-6">
                  Our Gecko-Inspired Grip keeps Covert securely attached to your watch — and removes just as easily,
                  with zero residue or wear.
                </p>
                <div className="space-y-4 text-zinc-400">
                  <p>
                    Covert uses cutting-edge dry adhesive technology modeled after gecko feet — the same kind of tech
                    being used in space travel. It's called biomimetic grip, and it's what makes our attachment system
                    so seamless.
                  </p>
                  <p>
                    Unlike traditional adhesives or straps, this innovative material delivers powerful hold without
                    magnets or sticky residue. It snaps on, stays on, and slips off clean — protecting even the most
                    luxurious timepieces.
                  </p>
                </div>
                <div className="mt-8 flex items-center gap-4">
                  <div className="h-2 w-2 rounded-full bg-[#00E5FF]"></div>
                  <span className="text-[#00E5FF] font-medium">Zero Damage. No Residue.</span>
                </div>
              </div>
              <div className="flex-1 order-1 lg:order-2 relative">
                <div className="relative rounded-lg overflow-hidden bg-zinc-900/50 border border-zinc-800 p-8">
                  <Image
                    src="/placeholder.svg?height=500&width=600"
                    width={600}
                    height={500}
                    alt="Gecko-inspired adhesive technology demonstration"
                    className="rounded-lg"
                  />
                  <div className="absolute inset-0 bg-gradient-radial from-[#00E5FF]/10 to-transparent opacity-60"></div>
                  <div className="absolute top-4 right-4 bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2">
                    <span className="text-xs text-[#00E5FF] font-medium">Biomimetic Tech</span>
                  </div>
                </div>
                <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-[#00E5FF]/20 rounded-full blur-2xl"></div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 md:py-28 bg-zinc-950">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Track Without <span className="text-[#00E5FF]">the Watch.</span>
              </h2>
              <p className="mt-4 text-xl text-zinc-300 max-w-3xl mx-auto">
                Don't want to wear your luxury watch to the gym? No problem. Covert comes with a sleek workout band —
                complementary with every tracker.
              </p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-12">
              <div className="relative">
                <div className="relative rounded-lg overflow-hidden aspect-video bg-zinc-900/50 border border-zinc-800">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    width={600}
                    height={400}
                    alt="Covert attached to luxury watch"
                    className="object-cover w-full h-full"
                  />
                  <div className="absolute bottom-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2">
                    <span className="text-sm text-white font-medium">Everyday Wear</span>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                </div>
              </div>
              <div className="relative">
                <div className="relative rounded-lg overflow-hidden aspect-video bg-zinc-900/50 border border-zinc-800">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    width={600}
                    height={400}
                    alt="Covert on workout band during exercise"
                    className="object-cover w-full h-full"
                  />
                  <div className="absolute bottom-4 left-4 bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2">
                    <span className="text-sm text-[#00E5FF] font-medium">Workout Mode</span>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent"></div>
                </div>
              </div>
            </div>
            <div className="max-w-2xl mx-auto">
              <p className="text-zinc-400 text-center mb-8">
                Whether you're training hard or keeping it casual, you shouldn't have to choose between fitness and
                peace of mind. That's why every Covert tracker includes a minimalist band designed for workouts.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="flex flex-col items-center text-center p-4">
                  <div className="h-10 w-10 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-3">
                    <span className="text-[#00E5FF] text-sm">✓</span>
                  </div>
                  <h4 className="font-medium text-white mb-1">Lightweight & Breathable</h4>
                  <p className="text-sm text-zinc-400">Designed for comfort during intense workouts</p>
                </div>
                <div className="flex flex-col items-center text-center p-4">
                  <div className="h-10 w-10 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-3">
                    <span className="text-[#00E5FF] text-sm">✓</span>
                  </div>
                  <h4 className="font-medium text-white mb-1">Secure Fit</h4>
                  <p className="text-sm text-zinc-400">Stays put during high-intensity training</p>
                </div>
                <div className="flex flex-col items-center text-center p-4">
                  <div className="h-10 w-10 rounded-full bg-[#00E5FF]/20 flex items-center justify-center mb-3">
                    <span className="text-[#00E5FF] text-sm">✓</span>
                  </div>
                  <h4 className="font-medium text-white mb-1">Easy Swap</h4>
                  <p className="text-sm text-zinc-400">Switch between band and watch in seconds</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="waitlist" className="py-20 md:py-28">
          <div className="container">
            <div className="max-w-2xl mx-auto text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Be the First to <span className="text-[#00E5FF]">Wear One.</span>
              </h2>
              <p className="mt-4 text-zinc-400">
                Sign up to get early access, exclusive updates, and a chance to be part of the beta.
              </p>
            </div>
            <div className="max-w-md mx-auto">
              <form className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="email">Email address</Label>
                  <Input
                    id="email"
                    placeholder="Enter your email"
                    type="email"
                    className="bg-zinc-900 border-zinc-800"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="watch-brand">Watch brand you wear (optional)</Label>
                  <Select>
                    <SelectTrigger className="bg-zinc-900 border-zinc-800">
                      <SelectValue placeholder="Select your watch brand" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="rolex">Rolex</SelectItem>
                      <SelectItem value="omega">Omega</SelectItem>
                      <SelectItem value="tag-heuer">TAG Heuer</SelectItem>
                      <SelectItem value="seiko">Seiko</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" className="w-full bg-[#00E5FF] text-black hover:bg-[#00E5FF]/90">
                  Join Waitlist
                </Button>
              </form>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t border-zinc-800 py-10">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2 text-xl font-bold">
              <span className="text-[#00E5FF]">COVERT</span>
              <span className="text-sm font-normal text-zinc-500">@trycovert</span>
            </div>
            <div className="flex gap-6">
              <Link href="#" aria-label="Instagram">
                <Instagram className="h-5 w-5 text-zinc-400 hover:text-[#00E5FF]" />
              </Link>
              <Link href="#" aria-label="Twitter">
                <Twitter className="h-5 w-5 text-zinc-400 hover:text-[#00E5FF]" />
              </Link>
              <Link href="#" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5 text-zinc-400 hover:text-[#00E5FF]" />
              </Link>
            </div>
            <div className="text-xs text-zinc-500">
              <p>This product is in development. Not affiliated with any watch brands listed above.</p>
              <div className="flex gap-4 mt-2">
                <Link href="#" className="hover:text-zinc-300">
                  Terms
                </Link>
                <Link href="#" className="hover:text-zinc-300">
                  Privacy
                </Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
